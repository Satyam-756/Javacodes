// Importing File Class
import java.io.File;
 
class GFG {
    public static void main(String[] args)
    {
 
        // File name specified
        File obj = new File("myfile.txt");
          System.out.println("File Created!");
    }
}