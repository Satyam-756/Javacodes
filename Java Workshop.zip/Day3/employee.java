public class Employee {
     
    static String Employee_name;
    static float Employee_salary;
 
    static void set(String n, float p) {
        Employee_name  = n;
        Employee_salary  = p;
    }
 
    static void get() {
        System.out.println("Employee name is: " +Employee_name+"\n" );
        System.out.println("Employee CTC is: " + Employee_salary+"\n");
    }
 
    public static void main(String args[]) {
        Employee.set("Rathod Avinash", 10000.0f);
        Employee.get();
    }
}